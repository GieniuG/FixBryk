$('html').on('mouseleave', ()=>{
	document.querySelector(".lastChanceCloseTrigger").click()
	document.querySelector(".last-chance").remove()
});	