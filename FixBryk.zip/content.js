document.cookie = "last-change-contents=true; expires:999, path:'/"
$('html').on('mouseleave', ()=>{
	document.querySelector(".lastChanceCloseTrigger").click()
	document.querySelector(".last-chance").remove()
});	